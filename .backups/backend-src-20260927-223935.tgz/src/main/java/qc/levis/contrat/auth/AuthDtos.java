package qc.levis.contrat.auth;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.List;

/** Objets de transfert du module d'authentification (réutilisable). */
public final class AuthDtos {
    private AuthDtos() {}

    public record LoginRequest(
            @Email @NotBlank String email,
            @NotBlank String motDePasse,
            String totpCode,
            List<String> securityAnswers,
            /** Slug du tenant issu du sous-domaine (ex. « levis » pour levis.contrat…). Optionnel. */
            String slug) {}

    /**
     * Réponse d'authentification. Sur succès : ok=true + profil (le jeton est posé
     * dans un cookie httpOnly). Si un second facteur est requis : mfaRequired=true.
     */
    public record AuthResponse(
            boolean ok,
            boolean mfaRequired,
            String securityMethod,          // "totp" | "question"
            List<String> securityQuestions, // questions dynamiques à présenter
            String email,
            String nom,
            List<String> roles,
            String error) {

        public static AuthResponse succes(String email, String nom, List<String> roles) {
            return new AuthResponse(true, false, null, null, email, nom, roles, null);
        }
        public static AuthResponse defiMfa(String methode, List<String> questions) {
            return new AuthResponse(false, true, methode, questions, null, null, null, null);
        }
        public static AuthResponse echec(String message) {
            return new AuthResponse(false, false, null, null, null, null, null, message);
        }
    }

    public record MeResponse(String email, String nom, String direction, List<String> roles,
                             boolean mfaActive, String mfaMethode) {}

    /** Mise à jour du profil personnel (self-service). */
    public record ProfileUpdateRequest(String nom, String direction,
                                       String motDePasseActuel, String nouveauMotDePasse) {}

    // Configuration du second facteur
    public record TotpSetupResponse(String secret, String uriOtpauth) {}
    public record TotpEnableRequest(@NotBlank String code) {}
    public record QuestionItem(@NotBlank String question, @NotBlank String reponse) {}
    public record QuestionSetupRequest(@NotNull List<QuestionItem> questions) {}
}
