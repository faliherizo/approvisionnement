package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.IntegrationM365;

import java.util.Optional;

public interface IntegrationM365Repository extends JpaRepository<IntegrationM365, Long> {
    Optional<IntegrationM365> findByTenantId(Long tenantId);
}
