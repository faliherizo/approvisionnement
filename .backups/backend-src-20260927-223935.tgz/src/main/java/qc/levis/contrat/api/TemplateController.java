package qc.levis.contrat.api;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import qc.levis.contrat.domain.Document;
import qc.levis.contrat.domain.DocumentTemplate;
import qc.levis.contrat.service.TemplateService;

import java.util.List;

/** Templates de documents nommés. */
@RestController
@RequestMapping("/api/templates")
public class TemplateController {

    private final TemplateService service;

    public TemplateController(TemplateService service) {
        this.service = service;
    }

    @GetMapping
    public List<DocumentTemplate> lister() {
        return service.lister();
    }

    @GetMapping("/{id}")
    public DocumentTemplate obtenir(@PathVariable Long id) {
        return service.obtenir(id);
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','REDACTEUR')")
    public DocumentTemplate creer(@Valid @RequestBody Dtos.TemplateRequest req) {
        return service.creer(req);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','REDACTEUR')")
    public DocumentTemplate modifier(@PathVariable Long id, @Valid @RequestBody Dtos.TemplateRequest req) {
        return service.modifier(id, req);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','REDACTEUR')")
    public ResponseEntity<Void> supprimer(@PathVariable Long id) {
        service.supprimer(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/instancier")
    @PreAuthorize("hasAnyRole('REDACTEUR','ADMIN')")
    public Document instancier(@PathVariable Long id,
                               @Valid @RequestBody Dtos.InstancierTemplateRequest req,
                               Authentication auth) {
        return service.instancier(id, req, auth != null ? auth.getName() : "anonyme");
    }
}
