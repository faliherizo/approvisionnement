package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.Tenant;

import java.util.Optional;

public interface TenantRepository extends JpaRepository<Tenant, Long> {
    Optional<Tenant> findBySlug(String slug);
    boolean existsBySlug(String slug);
}
