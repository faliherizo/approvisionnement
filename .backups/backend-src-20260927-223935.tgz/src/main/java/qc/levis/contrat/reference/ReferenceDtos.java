package qc.levis.contrat.reference;

import jakarta.validation.constraints.NotBlank;

/** DTOs des valeurs de référence (sélecteurs dynamiques). */
public final class ReferenceDtos {
    private ReferenceDtos() {}

    /** Option servie aux sélecteurs du frontend. */
    public record Option(String code, String libelle) {}

    /** Création/mise à jour d'une valeur de référence. */
    public record ReferenceRequest(
            @NotBlank String categorie,
            @NotBlank String code,
            @NotBlank String libelle,
            Integer ordre,
            Boolean actif) {}
}
