package qc.levis.contrat.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import qc.levis.contrat.api.Dtos;
import qc.levis.contrat.domain.DocumentAnnexe;
import qc.levis.contrat.repo.DocumentAnnexeRepository;

import java.util.List;

/** Annexes d'un document. L'accès est cadré par le tenant via {@link DocumentService}. */
@Service
public class AnnexeService {

    private final DocumentAnnexeRepository annexes;
    private final DocumentService documents;
    private final AuditService audit;

    public AnnexeService(DocumentAnnexeRepository annexes, DocumentService documents, AuditService audit) {
        this.annexes = annexes;
        this.documents = documents;
        this.audit = audit;
    }

    public List<DocumentAnnexe> lister(Long documentId) {
        documents.get(documentId); // vérifie l'appartenance au tenant
        return annexes.findByDocumentIdOrderByOrdreAsc(documentId);
    }

    @Transactional
    public DocumentAnnexe ajouter(Long documentId, Dtos.AnnexeRequest req, String utilisateur) {
        documents.get(documentId);
        DocumentAnnexe a = new DocumentAnnexe();
        a.setDocumentId(documentId);
        a.setNumero(req.numero());
        a.setTitre(req.titre());
        a.setReferenceClause(req.referenceClause());
        a.setContenu(req.contenu());
        a.setOrdre(annexes.findByDocumentIdOrderByOrdreAsc(documentId).size());
        DocumentAnnexe saved = annexes.save(a);
        audit.log(utilisateur, "AJOUT_ANNEXE", "Document", documentId, req.titre());
        return saved;
    }

    @Transactional
    public void supprimer(Long documentId, Long annexeId) {
        documents.get(documentId);
        annexes.findById(annexeId)
                .filter(a -> a.getDocumentId().equals(documentId))
                .ifPresent(annexes::delete);
    }
}
