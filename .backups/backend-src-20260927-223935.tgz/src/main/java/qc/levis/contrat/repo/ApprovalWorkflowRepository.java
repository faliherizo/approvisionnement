package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.ApprovalWorkflow;
import qc.levis.contrat.domain.Enums;

import java.util.List;
import java.util.Optional;

public interface ApprovalWorkflowRepository extends JpaRepository<ApprovalWorkflow, Long> {
    List<ApprovalWorkflow> findByTenantId(Long tenantId);
    Optional<ApprovalWorkflow> findFirstByTenantIdAndTypeAndActifTrue(Long tenantId, Enums.TypeContrat type);
}
