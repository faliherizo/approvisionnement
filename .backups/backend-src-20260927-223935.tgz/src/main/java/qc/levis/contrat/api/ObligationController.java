package qc.levis.contrat.api;

import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import qc.levis.contrat.domain.Obligation;
import qc.levis.contrat.service.ObligationService;

import java.util.List;

/** Obligations & échéances contractuelles. */
@RestController
@RequestMapping("/api")
public class ObligationController {

    private final ObligationService service;

    public ObligationController(ObligationService service) {
        this.service = service;
    }

    private String utilisateur(Authentication auth) {
        return auth != null ? auth.getName() : "anonyme";
    }

    @GetMapping("/documents/{documentId}/obligations")
    public List<Obligation> lister(@PathVariable Long documentId) {
        return service.lister(documentId);
    }

    @PostMapping("/documents/{documentId}/obligations")
    @PreAuthorize("hasAnyRole('REDACTEUR','APPRO','ADMIN')")
    public Obligation ajouter(@PathVariable Long documentId,
                              @Valid @RequestBody Dtos.ObligationRequest req,
                              Authentication auth) {
        return service.ajouter(documentId, req, utilisateur(auth));
    }

    /** Échéances à venir dans les {@code jours} prochains (défaut 30). */
    @GetMapping("/obligations/a-venir")
    public List<Obligation> aVenir(@RequestParam(name = "jours", defaultValue = "30") int jours) {
        return service.aVenir(jours);
    }

    @PostMapping("/obligations/{id}/completer")
    @PreAuthorize("hasAnyRole('REDACTEUR','APPRO','ADMIN')")
    public Obligation completer(@PathVariable Long id, Authentication auth) {
        return service.completer(id, utilisateur(auth));
    }
}
