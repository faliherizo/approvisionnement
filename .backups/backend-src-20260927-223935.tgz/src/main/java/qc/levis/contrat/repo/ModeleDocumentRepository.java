package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.ModeleDocument;

import java.util.Optional;

public interface ModeleDocumentRepository extends JpaRepository<ModeleDocument, Long> {
    Optional<ModeleDocument> findByTenantId(Long tenantId);
    Optional<ModeleDocument> findByTenantIdIsNull();
}
