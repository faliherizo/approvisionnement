package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.Addenda;

import java.util.List;

public interface AddendaRepository extends JpaRepository<Addenda, Long> {
    List<Addenda> findByDocumentParentIdOrderByNumeroAsc(Long documentParentId);
}
