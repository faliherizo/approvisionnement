package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.TarifTenant;

import java.util.Optional;

public interface TarifTenantRepository extends JpaRepository<TarifTenant, Long> {
    Optional<TarifTenant> findByTenantId(Long tenantId);
}
