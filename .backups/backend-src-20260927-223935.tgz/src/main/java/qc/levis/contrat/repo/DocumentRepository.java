package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.Document;

import java.util.List;

public interface DocumentRepository extends JpaRepository<Document, Long> {
    List<Document> findByCreePar(String creePar);
    List<Document> findByTenantId(Long tenantId);
    List<Document> findByTenantIdAndActifTrue(Long tenantId);
    List<Document> findByDossierIdAndActifTrue(Long dossierId);
    long countByDossierIdAndActifTrue(Long dossierId);
}
