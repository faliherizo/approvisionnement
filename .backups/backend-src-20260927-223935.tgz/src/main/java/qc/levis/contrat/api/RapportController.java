package qc.levis.contrat.api;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import qc.levis.contrat.service.RapportService;

/** Rapports de suivi consolidés (Addenda 1, exig. 22). Réservé aux rôles de pilotage. */
@RestController
@RequestMapping("/api/rapports")
public class RapportController {

    private final RapportService service;

    public RapportController(RapportService service) {
        this.service = service;
    }

    @GetMapping("/suivi")
    @PreAuthorize("hasAnyRole('APPRO','DIRECTION','ADMIN')")
    public Dtos.RapportSuivi suivi() {
        return service.suivi();
    }
}
