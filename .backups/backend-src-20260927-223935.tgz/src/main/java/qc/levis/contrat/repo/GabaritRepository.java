package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.Gabarit;

import java.util.List;
import java.util.Optional;

public interface GabaritRepository extends JpaRepository<Gabarit, Long> {
    List<Gabarit> findByTenantIdIsNullOrderByOrdreAscNomAsc();
    List<Gabarit> findByTenantIdOrderByOrdreAscNomAsc(Long tenantId);
    Optional<Gabarit> findByTenantIdAndCode(Long tenantId, String code);
    Optional<Gabarit> findByTenantIdIsNullAndCode(String code);
    long countByTenantIdIsNull();
}
