package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.IntegrationOidc;

import java.util.Optional;

public interface IntegrationOidcRepository extends JpaRepository<IntegrationOidc, Long> {
    Optional<IntegrationOidc> findByTenantId(Long tenantId);
}
