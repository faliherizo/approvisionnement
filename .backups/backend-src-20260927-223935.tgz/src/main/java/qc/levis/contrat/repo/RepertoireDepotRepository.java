package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.RepertoireDepot;

import java.util.List;
import java.util.Optional;

public interface RepertoireDepotRepository extends JpaRepository<RepertoireDepot, Long> {
    List<RepertoireDepot> findByUserIdOrderByCheminAsc(Long userId);
    boolean existsByUserIdAndChemin(Long userId, String chemin);
    Optional<RepertoireDepot> findByIdAndUserId(Long id, Long userId);
}
