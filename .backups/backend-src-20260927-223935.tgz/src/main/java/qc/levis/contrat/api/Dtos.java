package qc.levis.contrat.api;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import qc.levis.contrat.domain.Enums;

import java.math.BigDecimal;
import java.util.List;

/** Objets de transfert (requêtes/réponses de l'API REST). */
public final class Dtos {
    private Dtos() {}

    public record DocumentRequest(
            @NotBlank String titre,
            @NotNull Enums.TypeContrat type,
            Enums.ModeSollicitation modeSollicitation,
            BigDecimal valeurEstimee,
            String contexte,
            String numeroAO,
            String organismePublic,
            String prestataire,
            String gabaritCode,
            Long dossierId) {}

    public record ClauseSelectionRequest(List<Long> clauseIds) {}

    public record CommentRequest(@NotBlank String corps, Long clauseId, Long parentId) {}

    /** Résolution / réouverture d'un commentaire (art. 7.5). */
    public record CommentResolutionRequest(boolean resolu) {}

    public record ApprovalDecisionRequest(boolean approuve, String note) {}

    public record ClauseRequest(
            @NotBlank String code,
            @NotBlank String titre,
            @NotNull Enums.ClauseCategorie categorie,
            @NotBlank String corps,
            String numero,
            String section,
            boolean normative,
            List<String> dependances,
            List<String> exclusions,
            List<ConditionRequest> conditions) {}

    /** Condition d'éligibilité définie par l'admin (moteur de règles). */
    public record ConditionRequest(
            @NotNull Enums.AttributCondition attribut,
            @NotBlank String valeur) {}

    /** Modèle de mise en forme des documents générés (gabarit par entreprise). */
    public record ModeleDocumentRequest(String police, String couleurTitre, String couleurAccent,
                                        String marque, String piedDePage, Boolean afficherCouverture,
                                        String logoImage) {}

    /** Rédaction locale d'une section du document : texte adapté au dossier ou section libre. */
    public record DocumentClauseRequest(String titre, String section, String numero,
                                        String texteEffectif, Integer ordre) {}

    /** Création / modification d'un gabarit de document normalisé (couverture, corps, design). */
    public record GabaritRequest(String code, String nom,
                                 String surLabel, String label, String sousTitre, String piedLabel,
                                 String corps,
                                 String police, String couleurTitre, String couleurAccent, String logoImage,
                                 Boolean afficherCouverture,
                                 Integer margeGauche, Integer margeDroite, Integer margeHaut, Integer margeBas,
                                 Integer ordre, Boolean actif) {}

    /**
     * Clause proposée à l'assemblage : toutes les clauses actives sont exposées,
     * avec le verdict du moteur de règles ({@code eligible}) et l'auto-inclusion
     * ({@code autoInclus} = clause STANDARD éligible, intégrée sans sélection).
     */
    public record ClauseDisponible(Long id, String code, String titre, String categorie,
                                   boolean normative, boolean eligible, boolean autoInclus) {}

    public record AddendaRequest(@NotBlank String objet) {}

    public record AddendaChangeRequest(
            @NotNull Long clauseId,
            @NotBlank String nouveauTexte) {}

    // --- Vague 2 : versionnage, obligations, templates ---
    public record VersionRequest(String note) {}

    /** Instantané d'une clause dans une version (sérialisé en JSON). */
    public record ClauseSnapshot(String code, String titre, String texteEffectif, int ordre) {}

    public record ObligationRequest(
            @NotBlank String titre,
            String description,
            @NotNull Enums.ObligationType type,
            java.time.LocalDate dateEcheance,
            String responsable) {}

    public record TemplateRequest(
            @NotBlank String code,
            @NotBlank String nom,
            @NotNull Enums.TypeContrat type,
            Enums.ModeSollicitation modeSollicitation,
            Enums.TypeAcquisition categorieAcquisition,
            String description,
            String titreParDefaut,
            String contexte,
            String gabaritCode,
            List<String> clauseCodes,
            List<String> annexes) {}

    /** Création d'un document à partir d'un template. */
    public record InstancierTemplateRequest(
            @NotBlank String titre,
            java.math.BigDecimal valeurEstimee,
            String contexte) {}

    // --- Annexes & bordereau (contrats formels) ---
    public record AnnexeRequest(String numero, @NotBlank String titre,
                                String referenceClause, String contenu) {}

    public record LigneRequest(@NotBlank String description,
                               java.math.BigDecimal quantite, java.math.BigDecimal taux) {}

    public record BordereauRequest(String titre, List<LigneRequest> lignes) {}

    public record SignataireRequest(
            @NotBlank String nom,
            @Email @NotBlank String courriel,
            String role) {}

    public record SignerRequest(@NotBlank String nomComplet, String signatureImage) {}

    /** Assistance IA (Ollama) - rédaction de clause. */
    public record AiRedactionRequest(
            @NotBlank String instruction,
            String contexte,
            String texteExistant) {}

    public record AiRedactionResponse(String proposition, String modele) {}

    /** Base de connaissances IA (RAG). */
    public record KnowledgeRequest(@NotBlank String titre, String source, @NotBlank String contenu) {}

    /** Message de chat vers l'assistant IA spécialisé. */
    public record ChatRequest(@NotBlank String question, String contexteDocument) {}

    public record ChatResponse(String reponse, String modele, List<String> sources) {}

    // --- Dossier d'approvisionnement (P1 - art. 15) ---

    /** Création / mise à jour d'un dossier d'approvisionnement. */
    public record DossierRequest(
            @NotBlank String titre,
            String numeroAO,
            String objet,
            Enums.TypeAcquisition typeAcquisition,
            Enums.ModeSollicitation modeSollicitation,
            String responsable) {}

    /** Changement de statut d'un dossier (cycle de vie). */
    public record DossierStatutRequest(@NotNull Enums.StatutDossier statut) {}

    /**
     * Rapport de suivi d'un dossier (art. 15) : indicateurs agrégés sur les documents
     * rattachés — nombre total, répartition par statut, documents approuvés/signés.
     */
    public record DossierRapport(
            Long dossierId,
            String titre,
            Enums.StatutDossier statut,
            long nombreDocuments,
            long documentsApprouves,
            long documentsSignes,
            java.util.Map<String, Long> parStatut) {}

    // --- Assistant guidé de génération (P2 - art. 7.2, écart 5) ---

    /** Contexte saisi dans le parcours guidé, pour obtenir des recommandations. */
    public record AssistantContexteRequest(
            Enums.TypeContrat type,
            Enums.TypeAcquisition categorieAcquisition,
            BigDecimal valeurEstimee,
            String contexte) {}

    /** Template recommandé par l'assistant pour le contexte saisi. */
    public record TemplateRecommande(Long id, String code, String nom,
                                     Enums.TypeContrat type, Enums.TypeAcquisition categorieAcquisition,
                                     int nombreClauses, boolean correspondanceExacte) {}

    /** Clause éligible pré-visualisée pour le contexte (sans persistance). */
    public record ClauseApercu(Long id, String code, String titre, String categorie, boolean normative) {}

    /** Recommandations de l'assistant : mode suggéré, templates pertinents, clauses éligibles. */
    public record AssistantSuggestion(
            Enums.ModeSollicitation modeSuggere,
            List<TemplateRecommande> templatesRecommandes,
            List<ClauseApercu> clausesEligibles) {}

    /** Génération guidée d'un document (via template OU sélection manuelle), option de rattachement. */
    public record AssistantGenerationRequest(
            @NotBlank String titre,
            Long templateId,
            Enums.TypeContrat type,
            Enums.ModeSollicitation modeSollicitation,
            BigDecimal valeurEstimee,
            String contexte,
            Long dossierId,
            List<Long> clauseIds) {}

    // --- Encadrement IA (P6 - art. 21) ---

    /** Activation / désactivation de l'assistant IA pour le tenant. */
    public record IaParametreRequest(boolean activee) {}

    /** État de l'assistant IA pour le tenant. */
    public record IaParametre(boolean activee) {}

    // --- Import / migration de contenus (P6 - art. 22) ---

    /** Erreur de validation sur une ligne du fichier importé. */
    public record LigneErreur(int ligne, String message) {}

    /** Rapport d'import (mode essai ou réel) : compteurs et erreurs par ligne. */
    public record ImportRapport(boolean essai, int lignesLues, int valides, int importes,
                                List<LigneErreur> erreurs) {}

    /** Rapport d'import d'un modèle Word (.docx) : sections détectées, clauses créées, modèle. */
    public record ImportWordRapport(boolean essai, int sectionsDetectees, int clausesCreees,
                                    Long templateId, String templateNom, List<LigneErreur> erreurs) {}

    // --- Rapports de suivi consolidés (Addenda 1, exig. 22) ---

    /** Activité d'un utilisateur (nombre d'actions journalisées). */
    public record ActiviteUtilisateur(String utilisateur, long actions) {}

    /** Tableau de bord de suivi : portefeuille de documents + éléments d'action + activité. */
    public record RapportSuivi(
            long totalDocuments,
            java.util.Map<String, Long> documentsParStatut,
            java.util.Map<String, Long> documentsParType,
            long approbationsEnAttente,
            long dossiersActifs,
            long obligationsAVenir,
            List<ActiviteUtilisateur> activiteParUtilisateur) {}

    // --- Publication externe M365/SAP (P4 - art. 9, ADR-002) ---

    /** Demande de publication d'un document vers une cible externe. */
    public record PublicationRequest(
            @NotNull Enums.CiblePublication cible,
            Enums.FormatPublication format,
            String gabarit,
            String destination) {}

    /** Saisie de la configuration Microsoft 365 d'un tenant (espace admin). Secret write-only. */
    public record IntegrationM365Request(Boolean actif, String msTenantId, String clientId,
                                         String clientSecret, String sharepointSiteId, String driveId,
                                         String teamsTeamId, String teamsChannelId,
                                         String outlookExpediteur, String dossierRacine) {}

    /** Vue de la configuration M365 renvoyée au frontend : SANS le secret (juste sa présence). */
    public record IntegrationM365Vue(boolean actif, String msTenantId, String clientId,
                                     String sharepointSiteId, String driveId, String teamsTeamId,
                                     String teamsChannelId, String outlookExpediteur,
                                     String dossierRacine, boolean secretDefini) {}

    /** Saisie de la configuration SAP d'un tenant (espace admin). Secrets write-only. */
    public record IntegrationSapRequest(Boolean actif, String baseUrl, String servicePath, String auth,
                                        String username, String password, String apiKey) {}

    /** Vue de la configuration SAP renvoyée au frontend : SANS les secrets (juste leur présence). */
    public record IntegrationSapVue(boolean actif, String baseUrl, String servicePath, String auth,
                                    String username, boolean passwordDefini, boolean apiKeyDefini) {}

    /** Saisie de la configuration OIDC d'un tenant (espace admin). Secret client write-only. */
    public record IntegrationOidcRequest(Boolean actif, String issuer, String clientId,
                                         String clientSecret, String scopes, String boutonLibelle,
                                         String claimCourriel, Boolean autoProvision,
                                         String roleParDefaut) {}

    /** Vue de la configuration OIDC renvoyée au frontend : SANS le secret (juste sa présence). */
    public record IntegrationOidcVue(boolean actif, String issuer, String clientId, String scopes,
                                     String boutonLibelle, String claimCourriel, boolean autoProvision,
                                     String roleParDefaut, boolean secretDefini) {}

    /** Saisie de la configuration SAML 2.0 (SP) d'un tenant (espace admin). */
    public record IntegrationSamlRequest(Boolean actif, String idpEntityId, String idpSsoUrl,
                                         String idpCertificat, String spEntityId, String claimCourriel,
                                         String boutonLibelle, Boolean autoProvision,
                                         String roleParDefaut) {}

    /** Vue de la configuration SAML renvoyée au frontend (le certificat de l'IdP est public). */
    public record IntegrationSamlVue(boolean actif, String idpEntityId, String idpSsoUrl,
                                     String idpCertificat, String spEntityId, String claimCourriel,
                                     String boutonLibelle, boolean autoProvision, String roleParDefaut,
                                     boolean certificatDefini) {}

    // --- Workflow d'approbation configurable (P3 - art. 7.5, ADR-005) ---

    /** Gabarit de circuit d'approbation : rôles requis dans l'ordre, par type de document. */
    public record WorkflowRequest(
            @NotBlank String nom,
            @NotNull Enums.TypeContrat type,
            @NotNull List<Enums.Role> etapes,
            Boolean actif) {}

    // --- Recherche enrichie (P2 - art. 7.4, écart 10) ---

    /** Résultat de recherche à facettes (contenus réutilisables + documents + templates). */
    public record RechercheResultat(
            String terme,
            List<qc.levis.contrat.domain.Clause> clauses,
            List<qc.levis.contrat.domain.Document> documents,
            List<qc.levis.contrat.domain.DocumentTemplate> templates,
            java.util.Map<String, Long> facettesCategorieClause,
            int total) {}
}
