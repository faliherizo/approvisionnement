package qc.levis.contrat.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import qc.levis.contrat.api.Dtos;
import qc.levis.contrat.domain.Clause;
import qc.levis.contrat.domain.Document;
import qc.levis.contrat.domain.DocumentTemplate;
import qc.levis.contrat.domain.Enums;
import qc.levis.contrat.repo.ClauseRepository;
import qc.levis.contrat.repo.DocumentTemplateRepository;
import qc.levis.contrat.tenant.TenantContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Assistant guidé de génération (art. 7.2). Couche d'orchestration au-dessus du
 * {@link RuleEngine}, du {@link TemplateService} et du {@link DocumentService} : il
 * <em>ne réimplémente aucun moteur</em> (ADR-004). Il recommande un mode de sollicitation
 * et des templates, prévisualise les clauses éligibles, puis produit un document.
 */
@Service
public class AssistantGuideService {

    private final DocumentTemplateRepository templates;
    private final ClauseRepository clauses;
    private final RuleEngine ruleEngine;
    private final TemplateService templateService;
    private final DocumentService documentService;
    private final DossierService dossierService;
    private final AuditService audit;

    public AssistantGuideService(DocumentTemplateRepository templates, ClauseRepository clauses,
                                 RuleEngine ruleEngine, TemplateService templateService,
                                 DocumentService documentService, DossierService dossierService,
                                 AuditService audit) {
        this.templates = templates;
        this.clauses = clauses;
        this.ruleEngine = ruleEngine;
        this.templateService = templateService;
        this.documentService = documentService;
        this.dossierService = dossierService;
        this.audit = audit;
    }

    /** Analyse le contexte saisi et renvoie des recommandations (sans rien persister). */
    public Dtos.AssistantSuggestion analyser(Dtos.AssistantContexteRequest req) {
        Enums.ModeSollicitation modeSuggere = ruleEngine.modeSuggere(req.valeurEstimee());

        Document contexteTransitoire = new Document();
        contexteTransitoire.setType(req.type());
        contexteTransitoire.setModeSollicitation(modeSuggere);
        contexteTransitoire.setValeurEstimee(req.valeurEstimee());
        contexteTransitoire.setContexte(req.contexte());

        List<Dtos.ClauseApercu> eligibles = new ArrayList<>();
        for (Clause c : clauses.findByActifTrueAndTenantId(TenantContext.get())) {
            if (ruleEngine.estEligible(c, contexteTransitoire)) {
                eligibles.add(new Dtos.ClauseApercu(c.getId(), c.getCode(), c.getTitre(),
                        c.getCategorie().name(), c.isNormative()));
            }
        }

        List<Dtos.TemplateRecommande> recommandes = new ArrayList<>();
        for (DocumentTemplate t : templates.findByTenantId(TenantContext.get())) {
            boolean memeType = req.type() != null && req.type() == t.getType();
            boolean memeCategorie = req.categorieAcquisition() != null
                    && req.categorieAcquisition() == t.getCategorieAcquisition();
            if (memeType || memeCategorie) {
                recommandes.add(new Dtos.TemplateRecommande(t.getId(), t.getCode(), t.getNom(),
                        t.getType(), t.getCategorieAcquisition(), t.getClauseCodes().size(),
                        memeType && memeCategorie));
            }
        }
        recommandes.sort(Comparator.comparing(Dtos.TemplateRecommande::correspondanceExacte).reversed());

        return new Dtos.AssistantSuggestion(modeSuggere, recommandes, eligibles);
    }

    /**
     * Produit un document guidé : soit par instanciation d'un template, soit par création
     * puis assemblage d'une sélection manuelle. Rattache au dossier si demandé.
     */
    @Transactional
    public Document generer(Dtos.AssistantGenerationRequest req, String utilisateur) {
        Document document = req.templateId() != null
                ? genererDepuisTemplate(req, utilisateur)
                : genererManuellement(req, utilisateur);
        audit.log(utilisateur, "ASSISTANT_GENERER", "Document", document.getId(),
                req.templateId() != null ? "template=" + req.templateId() : "manuel");
        return document;
    }

    private Document genererDepuisTemplate(Dtos.AssistantGenerationRequest req, String utilisateur) {
        Document document = templateService.instancier(req.templateId(),
                new Dtos.InstancierTemplateRequest(req.titre(), req.valeurEstimee(), req.contexte()),
                utilisateur);
        if (req.dossierId() != null) {
            document = dossierService.rattacher(req.dossierId(), document.getId(), utilisateur);
        }
        return document;
    }

    private Document genererManuellement(Dtos.AssistantGenerationRequest req, String utilisateur) {
        Enums.ModeSollicitation mode = req.modeSollicitation() != null
                ? req.modeSollicitation()
                : ruleEngine.modeSuggere(req.valeurEstimee());
        Document cree = documentService.creer(new Dtos.DocumentRequest(
                req.titre(), req.type(), mode, req.valeurEstimee(), req.contexte(),
                null, null, null, null, req.dossierId()), utilisateur);
        return documentService.assembler(cree.getId(), req.clauseIds(), utilisateur);
    }
}
