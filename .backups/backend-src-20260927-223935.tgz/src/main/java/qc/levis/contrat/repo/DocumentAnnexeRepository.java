package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.DocumentAnnexe;

import java.util.List;

public interface DocumentAnnexeRepository extends JpaRepository<DocumentAnnexe, Long> {
    List<DocumentAnnexe> findByDocumentIdOrderByOrdreAsc(Long documentId);
}
