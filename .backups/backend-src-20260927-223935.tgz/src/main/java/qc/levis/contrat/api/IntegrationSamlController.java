package qc.levis.contrat.api;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import qc.levis.contrat.auth.SamlClient;
import qc.levis.contrat.service.IntegrationSamlService;
import qc.levis.contrat.service.port.PublicationCiblePort.ResultatPublication;
import qc.levis.contrat.tenant.TenantContext;

/**
 * Configuration SAML 2.0 (Service Provider) du tenant courant (espace admin → Paramètres).
 * L'administrateur du tenant saisit et active sa propre fédération SAML (ADFS, Azure AD, Shibboleth,
 * tout IdP SAML). Le certificat de signature de l'IdP est public : il est renvoyé tel quel.
 */
@RestController
@RequestMapping("/api/parametres/integration-saml")
@PreAuthorize("hasRole('ADMIN')")
public class IntegrationSamlController {

    private final IntegrationSamlService service;
    private final SamlClient client;

    public IntegrationSamlController(IntegrationSamlService service, SamlClient client) {
        this.service = service;
        this.client = client;
    }

    @GetMapping
    public Dtos.IntegrationSamlVue configuration() {
        return service.vue(TenantContext.get());
    }

    @PutMapping
    public Dtos.IntegrationSamlVue enregistrer(@RequestBody Dtos.IntegrationSamlRequest req) {
        return service.enregistrer(TenantContext.get(), req);
    }

    /**
     * Test de configuration : vérifie que la configuration est complète (EntityID, URL SSO,
     * certificat) et que le certificat X.509 de l'IdP est bien parsable. Aucun appel réseau.
     */
    @PostMapping("/test")
    public ResultatPublication tester(@RequestBody Dtos.IntegrationSamlRequest req) {
        return client.testerConfiguration(service.pourTest(TenantContext.get(), req));
    }
}
