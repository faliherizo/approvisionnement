package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.IntegrationSaml;

import java.util.Optional;

public interface IntegrationSamlRepository extends JpaRepository<IntegrationSaml, Long> {
    Optional<IntegrationSaml> findByTenantId(Long tenantId);
}
