package qc.levis.contrat.tenant;

import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import qc.levis.contrat.api.Dtos;
import qc.levis.contrat.auth.User;
import qc.levis.contrat.domain.ModeleDocument;
import qc.levis.contrat.domain.TarifTenant;
import qc.levis.contrat.domain.Tenant;
import qc.levis.contrat.service.ModeleDocumentService;
import qc.levis.contrat.service.TarifTenantService;

import java.util.List;

/** Espace superadmin : gestion des tenants et de leurs administrateurs. */
@RestController
@RequestMapping("/api/superadmin/tenants")
@PreAuthorize("hasRole('SUPERADMIN')")
public class TenantController {

    private final TenantAdminService service;
    private final ModeleDocumentService modeles;
    private final TarifTenantService tarifs;

    public TenantController(TenantAdminService service, ModeleDocumentService modeles,
                            TarifTenantService tarifs) {
        this.service = service;
        this.modeles = modeles;
        this.tarifs = tarifs;
    }

    @GetMapping
    public List<Tenant> lister() { return service.lister(); }

    @PostMapping
    public Tenant creer(@Valid @RequestBody TenantDtos.TenantRequest req) {
        return service.creer(req.slug(), req.titre(), req.sousTitre());
    }

    @PutMapping("/{id}")
    public Tenant mettreAJour(@PathVariable Long id,
                              @RequestBody TenantDtos.TenantUpdateRequest req) {
        return service.mettreAJour(id, req.titre(), req.sousTitre(), req.actif());
    }

    @PostMapping("/{id}/admin")
    public User creerAdmin(@PathVariable Long id,
                           @Valid @RequestBody TenantDtos.CreateTenantAdminRequest req) {
        return service.creerAdminTenant(id, req.email(), req.nom(), req.motDePasse());
    }

    @PutMapping("/{id}/theme")
    public Tenant theme(@PathVariable Long id, @RequestBody TenantDtos.ThemeRequest req) {
        return service.mettreAJourTheme(id, req);
    }

    /** Modèle de document (gabarit PDF/DOCX) d'un tenant précis. */
    @GetMapping("/{id}/modele-document")
    public ModeleDocument modeleDocument(@PathVariable Long id) {
        return modeles.pour(id);
    }

    @PutMapping("/{id}/modele-document")
    public ModeleDocument enregistrerModele(@PathVariable Long id,
                                            @RequestBody Dtos.ModeleDocumentRequest req) {
        return modeles.enregistrer(id, req);
    }

    /** Tarif d'abonnement d'un tenant précis. */
    @GetMapping("/{id}/tarif")
    public TarifTenant tarif(@PathVariable Long id) {
        return tarifs.pour(id);
    }

    @PutMapping("/{id}/tarif")
    public TarifTenant enregistrerTarif(@PathVariable Long id,
                                        @RequestBody TenantDtos.TarifTenantRequest req) {
        return tarifs.enregistrer(id, req);
    }
}
