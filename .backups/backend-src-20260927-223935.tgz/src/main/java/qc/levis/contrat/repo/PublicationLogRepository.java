package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.PublicationLog;

import java.util.List;

public interface PublicationLogRepository extends JpaRepository<PublicationLog, Long> {
    List<PublicationLog> findByDocumentIdOrderByPublieLeDesc(Long documentId);
}
