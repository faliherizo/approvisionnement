package qc.levis.contrat.admin;

import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import qc.levis.contrat.auth.User;
import qc.levis.contrat.tenant.TenantDtos;

import java.util.List;

/** Gestion des utilisateurs et des rôles (RBAC) d'un tenant — réservé aux admins. */
@RestController
@RequestMapping("/api/admin/users")
@PreAuthorize("hasRole('ADMIN')")
public class AdminUserController {

    private final AdminUserService service;

    public AdminUserController(AdminUserService service) {
        this.service = service;
    }

    @GetMapping
    public TenantDtos.PageResponse<User> lister(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int taille,
            @RequestParam(defaultValue = "") String q) {
        return service.lister(page, taille, q);
    }

    @GetMapping("/roles")
    public List<String> roles() { return service.rolesAssignables(); }

    @PostMapping
    public User creer(@Valid @RequestBody TenantDtos.AdminUserRequest req) {
        return service.creer(req);
    }

    @PutMapping("/{id}")
    public User modifier(@PathVariable Long id, @Valid @RequestBody TenantDtos.AdminUserRequest req) {
        return service.modifier(id, req);
    }

    @DeleteMapping("/{id}")
    public void supprimer(@PathVariable Long id) {
        service.supprimer(id);
    }
}
