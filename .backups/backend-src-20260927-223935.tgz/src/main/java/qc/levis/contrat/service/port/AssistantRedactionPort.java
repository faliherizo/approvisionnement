package qc.levis.contrat.service.port;

import qc.levis.contrat.api.Dtos;

/**
 * Port (architecture hexagonale) de l'assistance IA à la rédaction contractuelle.
 * L'implémentation par défaut est un modèle local Ollama ; on peut la substituer
 * (Azure OpenAI, Claude…) sans modifier les appelants (DIP / OCP).
 */
public interface AssistantRedactionPort {
    Dtos.AiRedactionResponse rediger(Dtos.AiRedactionRequest requete);
}
