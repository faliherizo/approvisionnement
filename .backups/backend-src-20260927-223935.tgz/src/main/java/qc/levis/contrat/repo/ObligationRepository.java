package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.Obligation;

import java.time.LocalDate;
import java.util.List;

public interface ObligationRepository extends JpaRepository<Obligation, Long> {
    List<Obligation> findByDocumentIdOrderByDateEcheanceAsc(Long documentId);
    List<Obligation> findByDateEcheanceLessThanEqualOrderByDateEcheanceAsc(LocalDate limite);
    List<Obligation> findByTenantIdAndDateEcheanceLessThanEqualOrderByDateEcheanceAsc(
            Long tenantId, LocalDate limite);
}
