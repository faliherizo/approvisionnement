package qc.levis.contrat.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import qc.levis.contrat.domain.*;
import qc.levis.contrat.repo.AddendaRepository;
import qc.levis.contrat.repo.DocumentRepository;

import java.time.Instant;
import java.util.List;
import java.util.NoSuchElementException;

/** Rédaction interactive d'addendas et réintégration au document (cf. BPMN). */
@Service
public class AddendaService {

    private final AddendaRepository addendas;
    private final DocumentRepository documents;
    private final AuditService audit;

    public AddendaService(AddendaRepository addendas, DocumentRepository documents, AuditService audit) {
        this.addendas = addendas;
        this.documents = documents;
        this.audit = audit;
    }

    public List<Addenda> lister(Long documentId) {
        return addendas.findByDocumentParentIdOrderByNumeroAsc(documentId);
    }

    public Addenda get(Long id) {
        return addendas.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Addenda introuvable: " + id));
    }

    @Transactional
    public Addenda creer(Long documentId, String objet, String utilisateur) {
        Document doc = documents.findById(documentId)
                .orElseThrow(() -> new NoSuchElementException("Document introuvable: " + documentId));
        int prochainNumero = addendas.findByDocumentParentIdOrderByNumeroAsc(documentId).size() + 1;
        Addenda a = new Addenda();
        a.setDocumentParentId(doc.getId());
        a.setNumero(prochainNumero);
        a.setObjet(objet);
        a.setStatut(Enums.StatutDocument.BROUILLON);
        Addenda saved = addendas.save(a);
        audit.log(utilisateur, "CREER_ADDENDA", "Addenda", saved.getId(), "n°" + prochainNumero);
        return saved;
    }

    /** Ajoute un changement de clause : capture le texte actuel comme « ancien ». */
    @Transactional
    public Addenda ajouterChangement(Long addendaId, Long clauseId, String nouveauTexte, String utilisateur) {
        Addenda a = get(addendaId);
        Document doc = documents.findById(a.getDocumentParentId()).orElseThrow();
        DocumentClause cible = doc.getClauses().stream()
                .filter(dc -> clauseId.equals(dc.getClauseId()))
                .findFirst()
                .orElseThrow(() -> new NoSuchElementException("Clause absente du document: " + clauseId));

        AddendaChange ch = new AddendaChange();
        ch.setClauseId(clauseId);
        ch.setCode(cible.getCode());
        ch.setAncienTexte(cible.getTexteEffectif());
        ch.setNouveauTexte(nouveauTexte);
        a.addChangement(ch);
        Addenda saved = addendas.save(a);
        audit.log(utilisateur, "ADDENDA_CHANGEMENT", "Addenda", addendaId, cible.getCode());
        return saved;
    }

    /**
     * Réintègre l'addenda : applique les nouveaux textes aux clauses du document,
     * marque l'addenda PUBLIE et replace le document en approbation (cf. BPMN).
     */
    @Transactional
    public Addenda reintegrer(Long addendaId, String utilisateur) {
        Addenda a = get(addendaId);
        Document doc = documents.findById(a.getDocumentParentId()).orElseThrow();
        for (AddendaChange ch : a.getChangements()) {
            doc.getClauses().stream()
                    .filter(dc -> ch.getClauseId().equals(dc.getClauseId()))
                    .forEach(dc -> dc.setTexteEffectif(ch.getNouveauTexte()));
        }
        doc.setStatut(Enums.StatutDocument.EN_APPROBATION);
        documents.save(doc);

        a.setStatut(Enums.StatutDocument.PUBLIE);
        a.setEmisLe(Instant.now());
        Addenda saved = addendas.save(a);
        audit.log(utilisateur, "REINTEGRER_ADDENDA", "Addenda", addendaId,
                a.getChangements().size() + " changement(s)");
        return saved;
    }
}
