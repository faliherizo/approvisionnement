package qc.levis.contrat.tenant;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

import java.util.List;

/** DTOs de la gestion multi-tenant (espace superadmin) et de la gestion des utilisateurs. */
public final class TenantDtos {
    private TenantDtos() {}

    public record TenantRequest(
            @NotBlank String slug,
            @NotBlank String titre,
            String sousTitre) {}

    public record TenantUpdateRequest(String titre, String sousTitre, Boolean actif) {}

    /** Tarif d'abonnement d'un tenant (gestion superadmin). */
    public record TarifTenantRequest(java.math.BigDecimal forfaitAnnuel, String devise,
                                     java.math.BigDecimal indexationPct, Integer nbUtilisateursInclus,
                                     String notes, Boolean actif) {}

    /** Thème / design d'un tenant (personnalisation superadmin). */
    public record ThemeRequest(String couleurPrimaire, String couleurAccent,
                               String couleurFond, String couleurTexte,
                               String logoTexte, String logoImage) {}

    public record Theme(String couleurPrimaire, String couleurAccent,
                        String couleurFond, String couleurTexte,
                        String logoTexte, String logoImage) {}

    /** Vue publique d'un tenant (page de connexion) incluant le thème. */
    public record TenantPublic(String slug, String titre, String sousTitre, Theme theme) {}

    /** Résumé public d'un tenant (sélecteur de connexion). */
    public record TenantResume(String slug, String titre) {}

    /** Création de l'administrateur d'un tenant (depuis l'espace superadmin). */
    public record CreateTenantAdminRequest(
            @Email @NotBlank String email,
            @NotBlank String nom,
            @NotBlank String motDePasse) {}

    // --- Gestion des utilisateurs (espace admin d'un tenant) ---
    public record AdminUserRequest(
            @Email @NotBlank String email,
            @NotBlank String nom,
            String direction,
            String motDePasse,
            List<String> roles,
            Boolean actif) {}

    public record PageResponse<T>(List<T> contenu, long total, int page, int taille) {}
}
