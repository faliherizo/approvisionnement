package qc.levis.contrat.api;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import qc.levis.contrat.auth.OidcClient;
import qc.levis.contrat.service.IntegrationOidcService;
import qc.levis.contrat.service.port.PublicationCiblePort.ResultatPublication;
import qc.levis.contrat.tenant.TenantContext;

/**
 * Configuration OpenID Connect du tenant courant (espace admin → Paramètres). L'administrateur du
 * tenant saisit et active sa propre connexion gouvernementale (Microsoft Entra ID ou tout IdP OIDC).
 * Le secret client n'est jamais renvoyé : seule sa présence est indiquée.
 */
@RestController
@RequestMapping("/api/parametres/integration-oidc")
@PreAuthorize("hasRole('ADMIN')")
public class IntegrationOidcController {

    private final IntegrationOidcService service;
    private final OidcClient client;

    public IntegrationOidcController(IntegrationOidcService service, OidcClient client) {
        this.service = service;
        this.client = client;
    }

    @GetMapping
    public Dtos.IntegrationOidcVue configuration() {
        return service.vue(TenantContext.get());
    }

    @PutMapping
    public Dtos.IntegrationOidcVue enregistrer(@RequestBody Dtos.IntegrationOidcRequest req) {
        return service.enregistrer(TenantContext.get(), req);
    }

    /**
     * Test de configuration : interroge la découverte OIDC ({@code .well-known/openid-configuration})
     * de l'émetteur du formulaire (ou celui déjà enregistré). Un 2xx confirme l'émetteur.
     */
    @PostMapping("/test")
    public ResultatPublication tester(@RequestBody Dtos.IntegrationOidcRequest req) {
        return client.testerDecouverte(service.issuerPourTest(TenantContext.get(), req));
    }
}
