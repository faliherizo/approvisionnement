package qc.levis.contrat.reference;

import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import qc.levis.contrat.domain.ReferenceValue;

import java.util.List;

/** Gestion des valeurs de référence SPÉCIFIQUES au tenant (admin). */
@RestController
@RequestMapping("/api/admin/reference")
@PreAuthorize("hasRole('ADMIN')")
public class AdminReferenceController {

    private final ReferenceService service;

    public AdminReferenceController(ReferenceService service) {
        this.service = service;
    }

    @GetMapping
    public List<ReferenceValue> lister(@RequestParam String categorie) {
        return service.lister(categorie, false);
    }

    @PostMapping
    public ReferenceValue creer(@Valid @RequestBody ReferenceDtos.ReferenceRequest req) {
        return service.creer(req, false);
    }

    @PutMapping("/{id}")
    public ReferenceValue modifier(@PathVariable Long id, @Valid @RequestBody ReferenceDtos.ReferenceRequest req) {
        return service.modifier(id, req, false);
    }

    @DeleteMapping("/{id}")
    public void supprimer(@PathVariable Long id) {
        service.supprimer(id, false);
    }
}
