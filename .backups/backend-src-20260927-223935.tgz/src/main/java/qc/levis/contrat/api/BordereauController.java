package qc.levis.contrat.api;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import qc.levis.contrat.domain.Bordereau;
import qc.levis.contrat.service.BordereauService;

/** Bordereau de prix d'un document contractuel. */
@RestController
@RequestMapping("/api/documents/{documentId}/bordereau")
public class BordereauController {

    private final BordereauService service;

    public BordereauController(BordereauService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<Bordereau> get(@PathVariable Long documentId) {
        Bordereau b = service.get(documentId);
        return b == null ? ResponseEntity.noContent().build() : ResponseEntity.ok(b);
    }

    @PutMapping
    @PreAuthorize("hasAnyRole('REDACTEUR','ADMIN')")
    public Bordereau enregistrer(@PathVariable Long documentId,
                                 @Valid @RequestBody Dtos.BordereauRequest req, Authentication auth) {
        return service.enregistrer(documentId, req, auth != null ? auth.getName() : "anonyme");
    }
}
