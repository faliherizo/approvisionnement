package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.Bordereau;

import java.util.Optional;

public interface BordereauRepository extends JpaRepository<Bordereau, Long> {
    Optional<Bordereau> findByDocumentId(Long documentId);
}
