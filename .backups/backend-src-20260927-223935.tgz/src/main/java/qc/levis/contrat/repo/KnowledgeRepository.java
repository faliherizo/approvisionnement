package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.KnowledgeSnippet;

import java.util.List;

public interface KnowledgeRepository extends JpaRepository<KnowledgeSnippet, Long> {
    List<KnowledgeSnippet> findByTenantId(Long tenantId);
    List<KnowledgeSnippet> findByTenantIdIsNull();
    long countByTenantIdIsNull();
}
