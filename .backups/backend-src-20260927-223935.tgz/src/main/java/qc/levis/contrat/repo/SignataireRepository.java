package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.Signataire;

import java.util.List;
import java.util.Optional;

public interface SignataireRepository extends JpaRepository<Signataire, Long> {
    List<Signataire> findByDocumentId(Long documentId);
    Optional<Signataire> findByJeton(String jeton);
}
