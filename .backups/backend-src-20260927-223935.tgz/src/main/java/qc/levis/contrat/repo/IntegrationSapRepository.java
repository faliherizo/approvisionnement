package qc.levis.contrat.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import qc.levis.contrat.domain.IntegrationSap;

import java.util.Optional;

public interface IntegrationSapRepository extends JpaRepository<IntegrationSap, Long> {
    Optional<IntegrationSap> findByTenantId(Long tenantId);
}
